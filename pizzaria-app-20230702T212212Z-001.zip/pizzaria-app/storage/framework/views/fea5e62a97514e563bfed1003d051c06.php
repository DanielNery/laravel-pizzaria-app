<!-- resources/views/recipes/show.blade.php -->
<h2><?php echo e($recipe['strMeal']); ?></h2>
<img src="<?php echo e($recipe['strMealThumb']); ?>" alt="<?php echo e($recipe['strMeal']); ?>" width="300">
<p>Category: <?php echo e($recipe['strCategory']); ?></p>
<p>Area: <?php echo e($recipe['strArea']); ?></p>
<p>Instructions: <?php echo e($recipe['strInstructions']); ?></p>
<?php /**PATH /home/daniel/projects/web/monolitos/pizzaria-app/resources/views/recipes/show.blade.php ENDPATH**/ ?>