<!-- resources/views/recipes/index.blade.php -->
<?php if(!is_null($recipes)): ?>
<?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><?php echo e($recipe['strMeal']); ?></h2>
    <img src="<?php echo e($recipe['strMealThumb']); ?>" alt="<?php echo e($recipe['strMeal']); ?>" width="200">
    <p>Category: <?php echo e($recipe['strCategory']); ?></p>
    <a href="<?php echo e(route('recipes.show', $recipe['idMeal'])); ?>">View Recipe</a>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <p>Receitas não encontradas.</p>
<?php endif; ?>
<?php /**PATH /home/daniel/projects/web/monolitos/pizzaria-app/resources/views/recipes/index.blade.php ENDPATH**/ ?>