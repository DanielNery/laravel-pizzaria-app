<div>
    <button onclick="subtractNumber('<?php echo e($uniqueId); ?>', '<?php echo e($price); ?>')" class="text-xl font-bold p-2 " style="color:#C53F3F"> - </button>
    <span id="number-<?php echo e($uniqueId); ?>" class="text-xl mx-2 text-white"><?php echo e($number); ?></span>
    <button onclick="addNumber('<?php echo e($uniqueId); ?>', '<?php echo e($price); ?>')" class="text-xl font-bold p-2" style="color:#C53F3F"> + </button>
</div>


<script>
    function addNumber(uniqueId, price) {
        var numberElement = document.getElementById('number-' + uniqueId);
        var priceTotalElement = document.getElementById("priceTotal");
        if (numberElement && priceTotalElement) {
            var currentValue = parseInt(numberElement.innerHTML);
            var currentPrice = parseInt(priceTotalElement.innerHTML);
            numberElement.innerHTML = currentValue + 1;
            priceTotalElement.innerHTML = currentPrice + parseInt(price);
        }
    }

    function subtractNumber(uniqueId, price) {
        var numberElement = document.getElementById('number-' + uniqueId);
        var priceTotalElement = document.getElementById("priceTotal");
        if (numberElement) {
            var currentValue = parseInt(numberElement.innerHTML);
            var currentPrice = parseInt(priceTotalElement.innerHTML);
            numberElement.innerHTML = currentValue - 1;
            priceTotalElement.innerHTML = currentPrice - parseInt(price);
        }
    }
</script>

<?php /**PATH /home/daniel/projects/web/monolitos/pizzaria-app/resources/views/components/number-sum-component.blade.php ENDPATH**/ ?>