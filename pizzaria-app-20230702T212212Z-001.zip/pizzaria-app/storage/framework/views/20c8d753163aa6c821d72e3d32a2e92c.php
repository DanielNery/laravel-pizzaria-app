
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Painel')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php echo e(__("Rastreamento de pedidos!")); ?>

                </div>
            </div>
        </div>
    </div>
    <div id="map" class="mx-auto w-3/4 h-96"></div>


    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php echo e(__("Acompanhamento de pedidos!")); ?>

                </div>
            </div>
        </div>
    </div>

    <div class="container flex align-middle justify-center">
        <h1 class="text-white text-center m-60" style="font-size: 52px">Pedido 001</h1>
        <?php if (isset($component)) { $__componentOriginaleef62e8ea4b537f86b24caf12d76b66a = $component; } ?>
<?php $component = App\View\Components\Timeline::resolve(['items' => $timelineItems] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('timeline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Timeline::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleef62e8ea4b537f86b24caf12d76b66a)): ?>
<?php $component = $__componentOriginaleef62e8ea4b537f86b24caf12d76b66a; ?>
<?php unset($__componentOriginaleef62e8ea4b537f86b24caf12d76b66a); ?>
<?php endif; ?>
    </div>

    <div class="container flex align-middle justify-center">
        <h1 class="text-white text-center m-60" style="font-size: 52px">Pedido 002</h1>
        <?php if (isset($component)) { $__componentOriginaleef62e8ea4b537f86b24caf12d76b66a = $component; } ?>
<?php $component = App\View\Components\Timeline::resolve(['items' => $timelineItems] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('timeline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Timeline::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleef62e8ea4b537f86b24caf12d76b66a)): ?>
<?php $component = $__componentOriginaleef62e8ea4b537f86b24caf12d76b66a; ?>
<?php unset($__componentOriginaleef62e8ea4b537f86b24caf12d76b66a); ?>
<?php endif; ?>
    </div>

    <div class="container flex align-middle justify-center">
        <h1 class="text-white text-center m-60" style="font-size: 52px">Pedido 003</h1>
        <?php if (isset($component)) { $__componentOriginaleef62e8ea4b537f86b24caf12d76b66a = $component; } ?>
<?php $component = App\View\Components\Timeline::resolve(['items' => $timelineItems] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('timeline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Timeline::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleef62e8ea4b537f86b24caf12d76b66a)): ?>
<?php $component = $__componentOriginaleef62e8ea4b537f86b24caf12d76b66a; ?>
<?php unset($__componentOriginaleef62e8ea4b537f86b24caf12d76b66a); ?>
<?php endif; ?>
    </div>




    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        var map = L.map('map').setView([51.5074, -0.1278], 12);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors'
        }).addTo(map);
    </script>


    <!-- <script>
        function initMap() {
            // Crie uma instância do mapa
            var map = new google.maps.Map(document.getElementById('map'), {
                center: {lat: -23.5505, lng: -46.6333}, // Define o centro do mapa com as coordenadas desejadas
                zoom: 12 // Define o nível de zoom do mapa
            });

            // Adicione marcador ou outros componentes do mapa, se necessário
            var marker = new google.maps.Marker({
                position: {lat: -23.5505, lng: -46.6333},
                map: map,
                title: 'Localização da minha pizzaria'
            });
        }
    </script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('GOOGLE_MAPS_API_KEY')); ?>&callback=initMap"></script> -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/daniel/projects/web/monolitos/pizzaria-app/resources/views/dashboard.blade.php ENDPATH**/ ?>