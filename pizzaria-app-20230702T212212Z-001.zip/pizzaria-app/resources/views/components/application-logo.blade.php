<img src="{{ asset('img/pizzalogo.png') }}" alt="" class="w-20 h-20" >
